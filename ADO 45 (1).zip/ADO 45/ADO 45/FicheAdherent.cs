﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ADO_45
{
    public partial class FicheAdherent : Form

    {
        
        Adherent AdhCourant = new Adherent();
        public FicheAdherent(bool modification, Adherent monAdh = null)
        {
            InitializeComponent();
            try
            {
                if (monAdh != null)
                {
                    AdhCourant = monAdh;
                }
                bs.DataSource = AdhCourant;//affecter l'objet auteur

                if (modification == false)
                {
                    txt_Nom.Enabled = false;
                    txt_Prenom.Enabled = false;
                    txt_Rue.Enabled = false;
                    txt_AdrCp.Enabled = false;
                    txt_AdrVille.Enabled  = false;
                    txt_Tel.Enabled = false;
                    txt_Mel.Enabled = false;
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private void btn_Annuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Valider_Click(object sender, EventArgs e)
        {
            if (ControleSaisies() == true)
            {
                if (AdhCourant.Num == 0) //cas d'un ajout
                {
                    AdhCourant = bs.Current as Adherent;
                    bool reponse = ManagerAdherent.AjouterAdherent(AdhCourant);
                }
                else //Cas d'une modification 
                {
                    AdhCourant = bs.Current as Adherent;
                    bool reponse = ManagerAdherent.ModifierAdherent(AdhCourant);
                }
                this.Close();

            }

        }
        private bool ControleSaisies()
        {
            bool controle = true;
            if (txt_Nom.Text == "")
            {
                MessageBox.Show("vous devez saisir un nom");
                controle = false;
            }
            if (txt_Prenom.Text == "")
            {
                MessageBox.Show("vous devez saisir un prenom");
                controle = false;
            }
            if (txt_Rue.Text == "")
            {
                MessageBox.Show("vous devez saisir une rue");
                controle = false;
            }

            if (txt_Tel.Text == "")
            {
                MessageBox.Show("vous devez saisir un numero de tel");
                controle = false;
            }
            if (txt_AdrVille.Text == "")
            {
                MessageBox.Show("vous devez saisir une adresse");
                controle = false;
            }

          
            if (txt_AdrCp.Text == "")
            {
                MessageBox.Show("vous devez saisir un code postal");
                controle = false;
            }
            return controle;
        }
    }
}
