﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ADO_45
{
    public partial class FicheAuteur : Form
    {

     
        

        Auteurs auteurCourant = new Auteurs();
        public FicheAuteur(bool modification,Auteurs monAuteur= null)
        {
            InitializeComponent();
        
            try
            {
                if(monAuteur != null)
                {
                    auteurCourant = monAuteur;
                }
                bs.DataSource = auteurCourant;//affecter l'objet auteur
              
                if(modification == false)
                {
                    txt_Nom.Enabled = false;
                    txt_Prenom.Enabled = false;
                    txt_Nation.Enabled = false; 
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message);
                throw;
            }
           
        }

        private void Btn_Annuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Valider_Click(object sender, EventArgs e)
        {
            if (ControleSaisies() == true)
            {
                if (auteurCourant.Num == 0) //cas d'un ajout
                {
                    auteurCourant = bs.Current as Auteurs;
                    bool reponse = ManagerAuteur.AjouterAuteur(auteurCourant);
                }
                else //Cas d'une modification 
                {
                    auteurCourant = bs.Current as Auteurs;
                    bool reponse = ManagerAuteur.ModifierAuteur(auteurCourant);
                }
                this.Close();

            }
            
        }
        /// <summary>
        /// controle saisie moçdif auteur
        /// </summary>
        /// <returns></returns>
         private bool ControleSaisies()
        {
            bool controle = true;
            if (txt_Nom.Text == "")
            {
                MessageBox.Show("vous devez saisir un nom");
                controle = false;
            }
            if (txt_Nation.Text == "")
            {
                MessageBox.Show("vous devez saisir une nationalite");
                controle = false;
            }
            if (txt_Prenom.Text == "")
            {
                MessageBox.Show("vous devez saisir un prenome");
                controle = false;
            }
            return controle;
         }
    }
}
