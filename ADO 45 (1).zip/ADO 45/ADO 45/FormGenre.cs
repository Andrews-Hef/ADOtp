﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ADO_45
{
    public partial class FormGenre : Form
    {
        List<Genre> lesgenres = new List<Genre>();
        public FormGenre()
        {
            InitializeComponent();
            RemplirListe();
        }

        private void RemplirListe()
        {
            try
            {
                //dataGridView1.Rows.Clear();
                //appelle Donne auteur et renvoi une liste 
                lesgenres = ManagerGenre.DonneGenre();
                bs.DataSource = lesgenres;

            }
            catch (Exception ex)
            {
                MessageBox.Show("erreur:" + ex.Message);
            }

            finally
            {

            }

        }

        

        private void Afficher_Click(object sender, EventArgs e)
        {
            Genre genreSelec = new Genre();
            DataGridViewRow ligne = dataGridView1.SelectedRows[0];
            genreSelec = ligne.DataBoundItem as Genre;
            if (genreSelec != null)
            {
                FicheGenre frm = new FicheGenre(false, genreSelec);
                frm.ShowDialog();
            }
        }

        private void Modifier_Click(object sender, EventArgs e)
        {
            Genre genreSelec = new Genre();
            DataGridViewRow ligne = dataGridView1.SelectedRows[0];
            genreSelec = ligne.DataBoundItem as Genre;
            if (genreSelec != null)
            {
                FicheGenre frm = new FicheGenre(true, genreSelec);
                frm.ShowDialog();
            }
        }

        private void Nouveau_Click(object sender, EventArgs e)
        {
            Genre genreSelec = new Genre();
            FicheGenre frm = new FicheGenre(true, genreSelec);
            frm.ShowDialog();
            RemplirListe();
        }

        private void Supprimer_Click(object sender, EventArgs e)
        {
            Genre genreSelec = new Genre();
            DataGridViewRow ligne = dataGridView1.SelectedRows[0];
            genreSelec = ligne.DataBoundItem as Genre;

            //boite dialogue qui demande l'accord avant suppression 
            const string message =
                "veux tu vraiment supprimer cette auteur ?";//question 
            const string caption = "Form Closing";
            var result = MessageBox.Show(message, caption,
                                         MessageBoxButtons.YesNo,
                                         MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // annule l'action
                ManagerGenre.SupprimerGenre(genreSelec);
                RemplirListe();
            }

        }
    }
}
