﻿
namespace ADO_45
{
    partial class FicheAdherent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lb_Num = new System.Windows.Forms.Label();
            this.lb_Nom = new System.Windows.Forms.Label();
            this.lb_Prenom = new System.Windows.Forms.Label();
            this.lb_AdrRue = new System.Windows.Forms.Label();
            this.lb_AdrCp = new System.Windows.Forms.Label();
            this.lb_AdrVille = new System.Windows.Forms.Label();
            this.lb_Tel = new System.Windows.Forms.Label();
            this.lb_Mel = new System.Windows.Forms.Label();
            this.txt_Num = new System.Windows.Forms.TextBox();
            this.txt_Nom = new System.Windows.Forms.TextBox();
            this.txt_Prenom = new System.Windows.Forms.TextBox();
            this.txt_Rue = new System.Windows.Forms.TextBox();
            this.txt_AdrCp = new System.Windows.Forms.TextBox();
            this.txt_AdrVille = new System.Windows.Forms.TextBox();
            this.txt_Tel = new System.Windows.Forms.TextBox();
            this.txt_Mel = new System.Windows.Forms.TextBox();
            this.btn_Annuler = new System.Windows.Forms.Button();
            this.btn_Valider = new System.Windows.Forms.Button();
            this.bs = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bs)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_Num
            // 
            this.lb_Num.AutoSize = true;
            this.lb_Num.Location = new System.Drawing.Point(213, 98);
            this.lb_Num.Name = "lb_Num";
            this.lb_Num.Size = new System.Drawing.Size(44, 13);
            this.lb_Num.TabIndex = 0;
            this.lb_Num.Text = "Numéro";
            // 
            // lb_Nom
            // 
            this.lb_Nom.AutoSize = true;
            this.lb_Nom.Location = new System.Drawing.Point(213, 136);
            this.lb_Nom.Name = "lb_Nom";
            this.lb_Nom.Size = new System.Drawing.Size(29, 13);
            this.lb_Nom.TabIndex = 1;
            this.lb_Nom.Text = "Nom";
            // 
            // lb_Prenom
            // 
            this.lb_Prenom.AutoSize = true;
            this.lb_Prenom.Location = new System.Drawing.Point(213, 176);
            this.lb_Prenom.Name = "lb_Prenom";
            this.lb_Prenom.Size = new System.Drawing.Size(43, 13);
            this.lb_Prenom.TabIndex = 2;
            this.lb_Prenom.Text = "Prenom";
            // 
            // lb_AdrRue
            // 
            this.lb_AdrRue.AutoSize = true;
            this.lb_AdrRue.Location = new System.Drawing.Point(215, 205);
            this.lb_AdrRue.Name = "lb_AdrRue";
            this.lb_AdrRue.Size = new System.Drawing.Size(27, 13);
            this.lb_AdrRue.TabIndex = 3;
            this.lb_AdrRue.Text = "Rue";
            // 
            // lb_AdrCp
            // 
            this.lb_AdrCp.AutoSize = true;
            this.lb_AdrCp.Location = new System.Drawing.Point(213, 239);
            this.lb_AdrCp.Name = "lb_AdrCp";
            this.lb_AdrCp.Size = new System.Drawing.Size(61, 13);
            this.lb_AdrCp.TabIndex = 4;
            this.lb_AdrCp.Text = "CodePostal";
            // 
            // lb_AdrVille
            // 
            this.lb_AdrVille.AutoSize = true;
            this.lb_AdrVille.Location = new System.Drawing.Point(213, 268);
            this.lb_AdrVille.Name = "lb_AdrVille";
            this.lb_AdrVille.Size = new System.Drawing.Size(26, 13);
            this.lb_AdrVille.TabIndex = 5;
            this.lb_AdrVille.Text = "Ville";
            // 
            // lb_Tel
            // 
            this.lb_Tel.AutoSize = true;
            this.lb_Tel.Location = new System.Drawing.Point(213, 308);
            this.lb_Tel.Name = "lb_Tel";
            this.lb_Tel.Size = new System.Drawing.Size(58, 13);
            this.lb_Tel.TabIndex = 6;
            this.lb_Tel.Text = "Telephone";
            // 
            // lb_Mel
            // 
            this.lb_Mel.AutoSize = true;
            this.lb_Mel.Location = new System.Drawing.Point(215, 353);
            this.lb_Mel.Name = "lb_Mel";
            this.lb_Mel.Size = new System.Drawing.Size(24, 13);
            this.lb_Mel.TabIndex = 7;
            this.lb_Mel.Text = "Mel";
            // 
            // txt_Num
            // 
            this.txt_Num.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bs, "Num", true));
            this.txt_Num.Location = new System.Drawing.Point(370, 98);
            this.txt_Num.Name = "txt_Num";
            this.txt_Num.Size = new System.Drawing.Size(100, 20);
            this.txt_Num.TabIndex = 8;
            // 
            // txt_Nom
            // 
            this.txt_Nom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bs, "Nom", true));
            this.txt_Nom.Location = new System.Drawing.Point(370, 136);
            this.txt_Nom.Name = "txt_Nom";
            this.txt_Nom.Size = new System.Drawing.Size(100, 20);
            this.txt_Nom.TabIndex = 9;
            // 
            // txt_Prenom
            // 
            this.txt_Prenom.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bs, "Prenom", true));
            this.txt_Prenom.Location = new System.Drawing.Point(370, 176);
            this.txt_Prenom.Name = "txt_Prenom";
            this.txt_Prenom.Size = new System.Drawing.Size(100, 20);
            this.txt_Prenom.TabIndex = 10;
            // 
            // txt_Rue
            // 
            this.txt_Rue.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bs, "AdrRue", true));
            this.txt_Rue.Location = new System.Drawing.Point(370, 205);
            this.txt_Rue.Name = "txt_Rue";
            this.txt_Rue.Size = new System.Drawing.Size(100, 20);
            this.txt_Rue.TabIndex = 11;
            // 
            // txt_AdrCp
            // 
            this.txt_AdrCp.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bs, "AdrCP", true));
            this.txt_AdrCp.Location = new System.Drawing.Point(370, 239);
            this.txt_AdrCp.Name = "txt_AdrCp";
            this.txt_AdrCp.Size = new System.Drawing.Size(100, 20);
            this.txt_AdrCp.TabIndex = 12;
            // 
            // txt_AdrVille
            // 
            this.txt_AdrVille.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bs, "AdrVille", true));
            this.txt_AdrVille.Location = new System.Drawing.Point(370, 268);
            this.txt_AdrVille.Name = "txt_AdrVille";
            this.txt_AdrVille.Size = new System.Drawing.Size(100, 20);
            this.txt_AdrVille.TabIndex = 13;
            // 
            // txt_Tel
            // 
            this.txt_Tel.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bs, "Tel", true));
            this.txt_Tel.Location = new System.Drawing.Point(370, 308);
            this.txt_Tel.Name = "txt_Tel";
            this.txt_Tel.Size = new System.Drawing.Size(100, 20);
            this.txt_Tel.TabIndex = 14;
            // 
            // txt_Mel
            // 
            this.txt_Mel.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bs, "Mel", true));
            this.txt_Mel.Location = new System.Drawing.Point(370, 353);
            this.txt_Mel.Name = "txt_Mel";
            this.txt_Mel.Size = new System.Drawing.Size(100, 20);
            this.txt_Mel.TabIndex = 15;
            // 
            // btn_Annuler
            // 
            this.btn_Annuler.Location = new System.Drawing.Point(216, 410);
            this.btn_Annuler.Name = "btn_Annuler";
            this.btn_Annuler.Size = new System.Drawing.Size(75, 23);
            this.btn_Annuler.TabIndex = 16;
            this.btn_Annuler.Text = "Annuler";
            this.btn_Annuler.UseVisualStyleBackColor = true;
            this.btn_Annuler.Click += new System.EventHandler(this.btn_Annuler_Click);
            // 
            // btn_Valider
            // 
            this.btn_Valider.Location = new System.Drawing.Point(370, 410);
            this.btn_Valider.Name = "btn_Valider";
            this.btn_Valider.Size = new System.Drawing.Size(75, 23);
            this.btn_Valider.TabIndex = 17;
            this.btn_Valider.Text = "Valider";
            this.btn_Valider.UseVisualStyleBackColor = true;
            this.btn_Valider.Click += new System.EventHandler(this.btn_Valider_Click);
            // 
            // bs
            // 
            this.bs.DataSource = typeof(ADO_45.Adherent);
            // 
            // FicheAdherent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 450);
            this.Controls.Add(this.btn_Valider);
            this.Controls.Add(this.btn_Annuler);
            this.Controls.Add(this.txt_Mel);
            this.Controls.Add(this.txt_Tel);
            this.Controls.Add(this.txt_AdrVille);
            this.Controls.Add(this.txt_AdrCp);
            this.Controls.Add(this.txt_Rue);
            this.Controls.Add(this.txt_Prenom);
            this.Controls.Add(this.txt_Nom);
            this.Controls.Add(this.txt_Num);
            this.Controls.Add(this.lb_Mel);
            this.Controls.Add(this.lb_Tel);
            this.Controls.Add(this.lb_AdrVille);
            this.Controls.Add(this.lb_AdrCp);
            this.Controls.Add(this.lb_AdrRue);
            this.Controls.Add(this.lb_Prenom);
            this.Controls.Add(this.lb_Nom);
            this.Controls.Add(this.lb_Num);
            this.Name = "FicheAdherent";
            this.Text = "FicheAdherent";
            ((System.ComponentModel.ISupportInitialize)(this.bs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Num;
        private System.Windows.Forms.Label lb_Nom;
        private System.Windows.Forms.Label lb_Prenom;
        private System.Windows.Forms.Label lb_AdrRue;
        private System.Windows.Forms.Label lb_AdrCp;
        private System.Windows.Forms.Label lb_AdrVille;
        private System.Windows.Forms.Label lb_Tel;
        private System.Windows.Forms.Label lb_Mel;
        private System.Windows.Forms.TextBox txt_Num;
        private System.Windows.Forms.TextBox txt_Nom;
        private System.Windows.Forms.TextBox txt_Prenom;
        private System.Windows.Forms.TextBox txt_Rue;
        private System.Windows.Forms.TextBox txt_AdrCp;
        private System.Windows.Forms.TextBox txt_AdrVille;
        private System.Windows.Forms.TextBox txt_Tel;
        private System.Windows.Forms.TextBox txt_Mel;
        private System.Windows.Forms.Button btn_Annuler;
        private System.Windows.Forms.Button btn_Valider;
        private System.Windows.Forms.BindingSource bs;
    }
}