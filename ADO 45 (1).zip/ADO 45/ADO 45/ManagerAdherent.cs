﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ADO_45
{
    public class ManagerAdherent
    {
        public static Adherent DonneAdherentDuReader(MySqlDataReader monReader)
        {//affecter  chaque element de monReader a auteurs

            Adherent unAdh = new Adherent();
            unAdh.Num = Convert.ToInt16(monReader["num"]);
            // si le nom de l'auteur est null alors je mets rien sinon je mets  le nom 
            unAdh.Nom = monReader["nom"] == DBNull.Value ? "" : monReader["nom"] as string;
            // si le prenom de l'auteur est null alors je mets rien sinon je mets  le prenom
            unAdh.Prenom = monReader["prenom"] == DBNull.Value ? "" : monReader["prenom"] as string;
            // si la nationalite de l'auteur est null alors je mets rien sinon je mets  la nationalite
            unAdh.AdrRue = monReader["adrRue"] == DBNull.Value ? "" : monReader["adrRue"] as string;
            //
            unAdh.AdrVille = monReader["adrVille"] == DBNull.Value ? "" : monReader["adrVille"] as string;
            //
            unAdh.Tel = monReader["tel"] == DBNull.Value ? "" : monReader["tel"] as string;
            //
            unAdh.Mel = monReader["mel"] == DBNull.Value ? "" : monReader["mel"] as string;

            return unAdh;
        }

        public static List<Adherent> DonneAdherents()
        {
            List<Adherent> lesAdherents = new List<Adherent>();
            MySqlCommand maRequete;
            MySqlDataReader monReader;

            Connection.Maconnection.Open();// lien a la classe  pour se connecter et ouvre la connections
            maRequete = Connection.Maconnection.CreateCommand();
            maRequete.CommandText = "select * from adherent order by  nom";
            monReader = maRequete.ExecuteReader();
            while (monReader.Read())
            {
                Adherent adh = ManagerAdherent.DonneAdherentDuReader(monReader);
                lesAdherents.Add(adh);

            }
            monReader.Close();
            Connection.Maconnection.Close();
            return lesAdherents;
        }
        public static Adherent DonneAdherentParId(int id)
        {
            Adherent a = new Adherent();
            return a;
        }

        public static bool ModifierAdherent(Adherent a)
        {
            MySqlCommand maRequete = Connection.Maconnection.CreateCommand();
            bool reponse = false;
            maRequete.CommandText = " update adherent set" +
             " nom=@paramNom, prenom=@paramPrenom, adrRue=@paramRue ,adrCP=@paramCP,adrVille=@paramVille, tel=@paramTel, mel=@paramMel  where num=@paramNum ";
            maRequete.Parameters.Clear();//annule tous les anciens paramètre 
                                         //ajoute les paramètre de la requete de modification 
                                         //preparationd des variable de la requete pour la modification

            maRequete.Parameters.AddWithValue("@paramNom", a.Nom);
            maRequete.Parameters.AddWithValue("@paramPrenom", a.Prenom);
            maRequete.Parameters.AddWithValue("@paramCP", a.AdrCP);
            maRequete.Parameters.AddWithValue("@paramNum", a.Num);
            maRequete.Parameters.AddWithValue("@paramRue", a.AdrRue);
            maRequete.Parameters.AddWithValue("@paramVille", a.AdrVille);
            maRequete.Parameters.AddWithValue("@paramTel", a.Tel);
            maRequete.Parameters.AddWithValue("@paramMel", a.Mel);
            try
            {
                Connection.Maconnection.Open();
                int resultat = maRequete.ExecuteNonQuery();
                Connection.Maconnection.Close();
                //renvoi si ca bien la modif a ete prise en compte
                if (resultat > 0) { reponse = true; }
                else { throw new Exception("une erreur s'est produite, l'adherent n'a pas été mis a jour "); }

                return reponse;
            }


            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public static bool SupprimerAdherent(Adherent a)
        {
            MySqlCommand maRequete = Connection.Maconnection.CreateCommand();
            bool reponse = false;
            maRequete.CommandText = "DELETE FROM `biblio`.`adherent` WHERE  num= @paramNum";
            maRequete.Parameters.Clear();//annule tous les anciens paramètre 
            maRequete.Parameters.AddWithValue("@paramNum", a.Num);
            try
            {
                Connection.Maconnection.Open();
                int resultat = maRequete.ExecuteNonQuery();
                Connection.Maconnection.Close();
                //renvoi si ca bien la modif a ete prise en compte
                if (resultat > 0) { reponse = true; }
                else { throw new Exception("une erreur s'est produite, l'adherent n'a pas été supprimé"); }

                return reponse;
            }


            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }


        }
        public static bool AjouterAdherent(Adherent a)
        {
            MySqlCommand maRequete = Connection.Maconnection.CreateCommand();
            bool reponse = false;
            maRequete.CommandText = " INSERT INTO adherent (nom, prenom, adrRue, adrCP, adrVille, tel, mel) VALUES(@paramNom, @paramPrenom, @paramRue, @paramCP, @paramVille, @paramTel, @paramMel)";
            maRequete.Parameters.Clear();//annule tous les anciens paramètre 
            //Ajout des parametres
            maRequete.Parameters.AddWithValue("@paramNom", a.Nom);
            maRequete.Parameters.AddWithValue("@paramPrenom", a.Prenom);
            maRequete.Parameters.AddWithValue("@paramCP", a.AdrCP);
            
            maRequete.Parameters.AddWithValue("@paramRue", a.AdrRue);
            maRequete.Parameters.AddWithValue("@paramVille", a.AdrVille);
            maRequete.Parameters.AddWithValue("@paramTel", a.Tel);
            maRequete.Parameters.AddWithValue("@paramMel", a.Mel);
            try
            {

                Connection.Maconnection.Open();
                int resultat = maRequete.ExecuteNonQuery();
                Connection.Maconnection.Close();
                //renvoi si ca bien la modif a ete prise en compte
                if (resultat > 0) { reponse = true; }
                else { throw new Exception("une erreur s'est produite, l'adherent n'a pas ete ajouter "); }

                return reponse;
            }


            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }
}
