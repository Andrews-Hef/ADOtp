﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ADO_45
{
    public partial class FicheGenre : Form
    {
        Genre GenreCourant = new Genre();
        public FicheGenre(bool modification, Genre monGenre = null)
        {
            InitializeComponent();
            try
            {
                if (monGenre != null)
                {
                    GenreCourant = monGenre;
                }
                bs.DataSource = GenreCourant;//affecter l'objet auteur

                if (modification == false)
                {
                    txt_Libelle.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                throw;
            }
        }

        private void btn_Annuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Valider_Click(object sender, EventArgs e)
        {
            if (ControleSaisies() == true)
            {
                if (GenreCourant.Num == 0) //cas d'un ajout
                {
                    GenreCourant = bs.Current as Genre;
                    bool reponse = ManagerGenre.AjouterGenre(GenreCourant);
                }
                else //Cas d'une modification 
                {
                    GenreCourant = bs.Current as Genre;
                    bool reponse = ManagerGenre.ModifierGenre(GenreCourant);
                }
                this.Close();

            }
        }

        private bool ControleSaisies()
        {
            bool controle = true;
            if (txt_Libelle.Text == "")
            {
                MessageBox.Show("vous devez saisir un libelle");
                controle = false;
            }
           
            return controle;
        }

       
    }
}
