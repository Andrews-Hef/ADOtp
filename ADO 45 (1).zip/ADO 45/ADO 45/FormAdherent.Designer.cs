﻿
namespace ADO_45
{
    partial class FormAdherent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prenom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrRue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrVille = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Afficher = new System.Windows.Forms.Button();
            this.Modifier = new System.Windows.Forms.Button();
            this.Nouveau = new System.Windows.Forms.Button();
            this.Supprimer = new System.Windows.Forms.Button();
            this.numDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prenomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrRueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrCPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrVilleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.melDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bs = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bs)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Num,
            this.Nom,
            this.Prenom,
            this.adrRue,
            this.adrCP,
            this.adrVille,
            this.Tel,
            this.mel,
            this.numDataGridViewTextBoxColumn,
            this.nomDataGridViewTextBoxColumn,
            this.prenomDataGridViewTextBoxColumn,
            this.adrRueDataGridViewTextBoxColumn,
            this.adrCPDataGridViewTextBoxColumn,
            this.adrVilleDataGridViewTextBoxColumn,
            this.telDataGridViewTextBoxColumn,
            this.melDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bs;
            this.dataGridView1.Location = new System.Drawing.Point(22, 12);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(709, 611);
            this.dataGridView1.TabIndex = 0;
            
            // 
            // Num
            // 
            this.Num.DataPropertyName = "Num";
            this.Num.HeaderText = "Num";
            this.Num.Name = "Num";
            this.Num.ReadOnly = true;
            // 
            // Nom
            // 
            this.Nom.DataPropertyName = "Nom";
            this.Nom.HeaderText = "Nom";
            this.Nom.Name = "Nom";
            this.Nom.ReadOnly = true;
            // 
            // Prenom
            // 
            this.Prenom.DataPropertyName = "Prenom";
            this.Prenom.HeaderText = "Prenom";
            this.Prenom.Name = "Prenom";
            this.Prenom.ReadOnly = true;
            // 
            // adrRue
            // 
            this.adrRue.DataPropertyName = "AdrRue";
            this.adrRue.HeaderText = "adrRue";
            this.adrRue.Name = "adrRue";
            this.adrRue.ReadOnly = true;
            // 
            // adrCP
            // 
            this.adrCP.DataPropertyName = "AdrCP";
            this.adrCP.HeaderText = "AdrCP";
            this.adrCP.Name = "adrCP";
            this.adrCP.ReadOnly = true;
            // 
            // adrVille
            // 
            this.adrVille.DataPropertyName = "AdrVille";
            this.adrVille.HeaderText = "AdrVille";
            this.adrVille.Name = "adrVille";
            this.adrVille.ReadOnly = true;
            // 
            // Tel
            // 
            this.Tel.DataPropertyName = "Tel";
            this.Tel.HeaderText = "Tel";
            this.Tel.Name = "Tel";
            this.Tel.ReadOnly = true;
            // 
            // mel
            // 
            this.mel.DataPropertyName = "Mel";
            this.mel.HeaderText = "Mel";
            this.mel.Name = "mel";
            this.mel.ReadOnly = true;
            // 
            // Afficher
            // 
            this.Afficher.Location = new System.Drawing.Point(871, 78);
            this.Afficher.Name = "Afficher";
            this.Afficher.Size = new System.Drawing.Size(75, 23);
            this.Afficher.TabIndex = 1;
            this.Afficher.Text = "Afficher";
            this.Afficher.UseVisualStyleBackColor = true;
            this.Afficher.Click += new System.EventHandler(this.Afficher_Click);
            // 
            // Modifier
            // 
            this.Modifier.Location = new System.Drawing.Point(871, 146);
            this.Modifier.Name = "Modifier";
            this.Modifier.Size = new System.Drawing.Size(75, 23);
            this.Modifier.TabIndex = 2;
            this.Modifier.Text = "Modifier";
            this.Modifier.UseVisualStyleBackColor = true;
            this.Modifier.Click += new System.EventHandler(this.Modifier_Click);
            // 
            // Nouveau
            // 
            this.Nouveau.Location = new System.Drawing.Point(871, 233);
            this.Nouveau.Name = "Nouveau";
            this.Nouveau.Size = new System.Drawing.Size(75, 23);
            this.Nouveau.TabIndex = 3;
            this.Nouveau.Text = "Nouveau";
            this.Nouveau.UseVisualStyleBackColor = true;
            // 
            // Supprimer
            // 
            this.Supprimer.Location = new System.Drawing.Point(871, 305);
            this.Supprimer.Name = "Supprimer";
            this.Supprimer.Size = new System.Drawing.Size(75, 23);
            this.Supprimer.TabIndex = 4;
            this.Supprimer.Text = "Supprimer";
            this.Supprimer.UseVisualStyleBackColor = true;
            this.Supprimer.Click += new System.EventHandler(this.Supprimer_Click);
            // 
            // numDataGridViewTextBoxColumn
            // 
            this.numDataGridViewTextBoxColumn.DataPropertyName = "Num";
            this.numDataGridViewTextBoxColumn.HeaderText = "Num";
            this.numDataGridViewTextBoxColumn.Name = "numDataGridViewTextBoxColumn";
            this.numDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nomDataGridViewTextBoxColumn
            // 
            this.nomDataGridViewTextBoxColumn.DataPropertyName = "Nom";
            this.nomDataGridViewTextBoxColumn.HeaderText = "Nom";
            this.nomDataGridViewTextBoxColumn.Name = "nomDataGridViewTextBoxColumn";
            this.nomDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prenomDataGridViewTextBoxColumn
            // 
            this.prenomDataGridViewTextBoxColumn.DataPropertyName = "Prenom";
            this.prenomDataGridViewTextBoxColumn.HeaderText = "Prenom";
            this.prenomDataGridViewTextBoxColumn.Name = "prenomDataGridViewTextBoxColumn";
            this.prenomDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // adrRueDataGridViewTextBoxColumn
            // 
            this.adrRueDataGridViewTextBoxColumn.DataPropertyName = "AdrRue";
            this.adrRueDataGridViewTextBoxColumn.HeaderText = "AdrRue";
            this.adrRueDataGridViewTextBoxColumn.Name = "adrRueDataGridViewTextBoxColumn";
            this.adrRueDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // adrCPDataGridViewTextBoxColumn
            // 
            this.adrCPDataGridViewTextBoxColumn.DataPropertyName = "AdrCP";
            this.adrCPDataGridViewTextBoxColumn.HeaderText = "AdrCP";
            this.adrCPDataGridViewTextBoxColumn.Name = "adrCPDataGridViewTextBoxColumn";
            this.adrCPDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // adrVilleDataGridViewTextBoxColumn
            // 
            this.adrVilleDataGridViewTextBoxColumn.DataPropertyName = "AdrVille";
            this.adrVilleDataGridViewTextBoxColumn.HeaderText = "AdrVille";
            this.adrVilleDataGridViewTextBoxColumn.Name = "adrVilleDataGridViewTextBoxColumn";
            this.adrVilleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // telDataGridViewTextBoxColumn
            // 
            this.telDataGridViewTextBoxColumn.DataPropertyName = "Tel";
            this.telDataGridViewTextBoxColumn.HeaderText = "Tel";
            this.telDataGridViewTextBoxColumn.Name = "telDataGridViewTextBoxColumn";
            this.telDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // melDataGridViewTextBoxColumn
            // 
            this.melDataGridViewTextBoxColumn.DataPropertyName = "Mel";
            this.melDataGridViewTextBoxColumn.HeaderText = "Mel";
            this.melDataGridViewTextBoxColumn.Name = "melDataGridViewTextBoxColumn";
            this.melDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bs
            // 
            this.bs.DataSource = typeof(ADO_45.Adherent);
            // 
            // FormAdherent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1075, 635);
            this.Controls.Add(this.Supprimer);
            this.Controls.Add(this.Nouveau);
            this.Controls.Add(this.Modifier);
            this.Controls.Add(this.Afficher);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FormAdherent";
            this.Text = "Adherent";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bs)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button Afficher;
        private System.Windows.Forms.Button Modifier;
        private System.Windows.Forms.Button Nouveau;
        private System.Windows.Forms.Button Supprimer;
        private System.Windows.Forms.BindingSource bs;
        private System.Windows.Forms.DataGridViewTextBoxColumn Num;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nom;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prenom;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrRue;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrVille;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel;
        private System.Windows.Forms.DataGridViewTextBoxColumn mel;
        private System.Windows.Forms.DataGridViewTextBoxColumn numDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prenomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrRueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrCPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrVilleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn melDataGridViewTextBoxColumn;
    }
}