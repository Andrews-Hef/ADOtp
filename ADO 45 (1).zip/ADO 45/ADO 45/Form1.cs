﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ADO_45
{
    public partial class Form1 : Form
    {
        List<Auteurs> lesAuteurs = new List<Auteurs>();
       
        public Form1()
        {
            InitializeComponent();
            RemplirListe();
        }
        private void RemplirListe()
        {
            try
            {
                //dataGridView1.Rows.Clear();
                //appelle Donne auteur et renvoi une liste 
                lesAuteurs = ManagerAuteur.DonneAuteurs();
                bs.DataSource = lesAuteurs;
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("erreur:" +ex.Message);
            }

            finally
            {
                
            }
        }

        private void btn_Afficher_Click(object sender, EventArgs e)
        {
            Auteurs AuteurSelectionne = new Auteurs();
            DataGridViewRow ligne = dataGridView1.SelectedRows[0];
            AuteurSelectionne = ligne.DataBoundItem as Auteurs;
            if(AuteurSelectionne != null)
            {
                FicheAuteur frm = new FicheAuteur(false, AuteurSelectionne);
                frm.ShowDialog();
            }
           
        }

        private void btn_Modifier_Click(object sender, EventArgs e)
        {

            Auteurs AuteurSelectionne = new Auteurs();
            DataGridViewRow ligne = dataGridView1.SelectedRows[0];
            AuteurSelectionne = ligne.DataBoundItem as Auteurs;
            if (AuteurSelectionne != null)
            {
                FicheAuteur frm = new FicheAuteur(true, AuteurSelectionne);
                frm.ShowDialog();
            }

        }

        private void btn_Nouveau_Click(object sender, EventArgs e)
        {
            Auteurs AuteurSelectionne = new Auteurs();
            FicheAuteur frm = new FicheAuteur(true, AuteurSelectionne);
                frm.ShowDialog();
            RemplirListe();
            
        }

        private void btn_Supprimer_Click(object sender, EventArgs e)
        {
            Auteurs AuteurSelectionne = new Auteurs();
            DataGridViewRow ligne = dataGridView1.SelectedRows[0];
            AuteurSelectionne = ligne.DataBoundItem as Auteurs;
            
            //boite dialogue qui demande l'accord avant suppression 
            const string message =
                "veux tu vraiment supprimer cette auteur ?";//question 
            const string caption = "Form Closing";
            var result = MessageBox.Show(message, caption,
                                         MessageBoxButtons.YesNo,
                                         MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // annule l'action
                ManagerAuteur.SupprimerAuteur(AuteurSelectionne);
                RemplirListe();
            }

            
            

            

        }
        

    }
}
