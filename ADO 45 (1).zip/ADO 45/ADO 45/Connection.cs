﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ADO_45
{
    class Connection
    {
        //connection  a la base de données
        private static string connectionString = "server=127.0.0.1;port=3306;Database=biblio;Uid=root;password=";
        private static MySqlConnection maconnection = new MySqlConnection(connectionString) ;

        public static MySqlConnection Maconnection { get => maconnection; }
    }
}
