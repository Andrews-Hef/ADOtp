﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ADO_45
{
     public class ManagerGenre
    {
        public static Genre DonneGenreDuReader(MySqlDataReader monReader)
        {//affecter  chaque element de monReader a auteurs

            Genre ungenre = new Genre();
            ungenre.Num = Convert.ToInt16(monReader["num"]);
            // si le nom de l'auteur est null alors je mets rien sinon je mets  le nom 
            ungenre.Libelle = monReader["libelle"] == DBNull.Value ? "" : monReader["libelle"] as string;

            return ungenre;
        }

        public static List<Genre> DonneGenre()
        {
            List<Genre> lesGenres = new List<Genre>();
            MySqlCommand maRequete;
            MySqlDataReader monReader;

            Connection.Maconnection.Open();// lien a la classe  pour se connecter et ouvre la connections
            maRequete = Connection.Maconnection.CreateCommand();
            maRequete.CommandText = "select * from genre order by  num";
            monReader = maRequete.ExecuteReader();
            while (monReader.Read())
            {
                Genre genre = ManagerGenre.DonneGenreDuReader(monReader);
                lesGenres.Add(genre);

            }
            monReader.Close();
            Connection.Maconnection.Close();
            return lesGenres;
        }
        public static Genre DonneGenreParId(int id)
        {
            Genre g = new Genre();
            return g;
        }
        public static bool AjouterGenre(Genre g)
        {
            MySqlCommand maRequete = Connection.Maconnection.CreateCommand();
            bool reponse = false;
            maRequete.CommandText = "INSERT INTO genre (`libelle`) VALUES(@paramLibelle)";
            maRequete.Parameters.Clear();//annule tous les anciens paramètre 
            //Ajout des parametres
            maRequete.Parameters.AddWithValue("@paramLibelle", g.Libelle);
           
            try
            {
                Connection.Maconnection.Open();
                int resultat = maRequete.ExecuteNonQuery();
                Connection.Maconnection.Close();
                //renvoi si ca bien la modif a ete prise en compte
                if (resultat > 0) { reponse = true; }
                else { throw new Exception("une erreur s'est produite, le genre n'a pas ete ajouter "); }

                return reponse;
            }


            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public static bool ModifierGenre(Genre g)
        {
            MySqlCommand maRequete = Connection.Maconnection.CreateCommand();
            bool reponse = false;
            maRequete.CommandText = " update genre set" +
             " libelle=@paramLibelle";
            maRequete.Parameters.Clear();//annule tous les anciens paramètre 
                                         //ajoute les paramètre de la requete de modification 
                                         //preparationd des variable de la requete pour la modification

            maRequete.Parameters.AddWithValue("@paramLibelle", g.Libelle);
            
            try
            {
                Connection.Maconnection.Open();
                int resultat = maRequete.ExecuteNonQuery();
                Connection.Maconnection.Close();
                //renvoi si ca bien la modif a ete prise en compte
                if (resultat > 0) { reponse = true; }
                else { throw new Exception("une erreur s'est produite, le genre n'a pas été mis a jour "); }

                return reponse;
            }


            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public static bool SupprimerGenre(Genre g)
        {
            MySqlCommand maRequete = Connection.Maconnection.CreateCommand();
            bool reponse = false;
            maRequete.CommandText = "DELETE FROM `biblio`.`genre` WHERE  num= @paramNum";
            maRequete.Parameters.Clear();//annule tous les anciens paramètre 
            maRequete.Parameters.AddWithValue("@paramNum", g.Num);
            try
            {
                Connection.Maconnection.Open();
                int resultat = maRequete.ExecuteNonQuery();
                Connection.Maconnection.Close();
                //renvoi si ca bien la modif a ete prise en compte
                if (resultat > 0) { reponse = true; }
                else { throw new Exception("une erreur s'est produite, le genre n'a pas été supprimé"); }

                return reponse;
            }


            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }


        }
    }
}
