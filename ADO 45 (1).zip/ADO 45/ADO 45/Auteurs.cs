﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ADO_45
{
     public class Auteurs
    {
        private int num;
        private string nom = "";
        private string prenom = "";
        private string nation = "";

        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        public string Nation { get => nation; set => nation = value; }
        public int Num { get => num; set => num = value; }
    }
}
