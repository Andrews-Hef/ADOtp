﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ADO_45
{
     public class ManagerAuteur
    {
        //classe ou il ya tout les methode CRUD
        
        public static Auteurs DonneAuteurDuReader(MySqlDataReader monReader)
        {//affecter  chaque element de monReader a auteurs
            
            Auteurs unAuteur = new Auteurs();
            unAuteur.Num = Convert.ToInt16(monReader["num"]);
            // si le nom de l'auteur est null alors je mets rien sinon je mets  le nom 
            unAuteur.Nom = monReader["nom"] == DBNull.Value ? "" : monReader["nom"] as string;
            // si le prenom de l'auteur est null alors je mets rien sinon je mets  le prenom
            unAuteur.Prenom = monReader["prenom"] == DBNull.Value ? "" : monReader["prenom"] as string;
            // si la nationalite de l'auteur est null alors je mets rien sinon je mets  la nationalite
            unAuteur.Nation = monReader["nationalite"] == DBNull.Value ? "" : monReader["nationalite"] as string;
            return unAuteur;
        }
         public static List<Auteurs> DonneAuteurs()
        {
            List<Auteurs> lesAuteurs = new List<Auteurs>();
              MySqlCommand maRequete;
              MySqlDataReader monReader;

            Connection.Maconnection.Open();// lien a la classe  pour se connecter et ouvre la connections
            maRequete = Connection.Maconnection.CreateCommand();
            maRequete.CommandText = "select * from auteur order by  nom";
            monReader = maRequete.ExecuteReader();
            while (monReader.Read())
            {
                Auteurs unAuteurs = ManagerAuteur.DonneAuteurDuReader(monReader);
                lesAuteurs.Add(unAuteurs);
                   
            }
            monReader.Close();
            Connection.Maconnection.Close();
            return lesAuteurs;
        }
        //find auteur by id
        public static Auteurs DonneAuteurParId(int id)
        {
            Auteurs a = new Auteurs();
             return a;
        }
        public static bool AjouterAuteur(Auteurs a) 
        {
            MySqlCommand maRequete = Connection.Maconnection.CreateCommand();
            bool reponse = false;
            maRequete.CommandText = "INSERT INTO auteur (`nom`, `prenom`, `nationalite`) VALUES(@paramNom, @paramPrenom, @paramNation)";
            maRequete.Parameters.Clear();//annule tous les anciens paramètre 
            //Ajout des parametres
            maRequete.Parameters.AddWithValue("@paramNom", a.Nom);
            maRequete.Parameters.AddWithValue("@paramPrenom", a.Prenom);
            maRequete.Parameters.AddWithValue("@paramNation", a.Nation);
            try
            {
                Connection.Maconnection.Open();
                int resultat = maRequete.ExecuteNonQuery();
                Connection.Maconnection.Close();
                //renvoi si ca bien la modif a ete prise en compte
                if (resultat > 0) { reponse = true; }
                else { throw new Exception("une erreur s'est produite, l'auteur n'a pas ete ajouter "); }

                return reponse;
            }


            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public static bool ModifierAuteur(Auteurs a)
        {
            MySqlCommand maRequete = Connection.Maconnection.CreateCommand();
            bool reponse = false; 
            maRequete.CommandText = " update auteur set" +
             " nom=@paramNom, prenom=@paramPrenom, nationalite=@paramNation where num=@paramNum ";
            maRequete.Parameters.Clear();//annule tous les anciens paramètre 
            //ajoute les paramètre de la requete de modification 
             //preparationd des variable de la requete pour la modification

            maRequete.Parameters.AddWithValue("@paramNom", a.Nom);
            maRequete.Parameters.AddWithValue("@paramPrenom", a.Prenom);
            maRequete.Parameters.AddWithValue("@paramNation", a.Nation);
            maRequete.Parameters.AddWithValue("@paramNum", a.Num);
            try
            {
                Connection.Maconnection.Open();
                int resultat = maRequete.ExecuteNonQuery();
                Connection.Maconnection.Close();
                //renvoi si ca bien la modif a ete prise en compte
                if (resultat > 0) { reponse = true;  }
                else { throw new Exception("une erreur s'est produite, l'auter n'a pas été mis a jour "); }
               
                return reponse;
            }
           
            
             catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static bool SupprimerAuteur(Auteurs a)
        {
            MySqlCommand maRequete = Connection.Maconnection.CreateCommand();
            bool reponse = false;
            maRequete.CommandText = "DELETE FROM `biblio`.`auteur` WHERE  num= @paramNum";
            maRequete.Parameters.Clear();//annule tous les anciens paramètre 
            maRequete.Parameters.AddWithValue("@paramNum", a.Num);
            try
            {
                Connection.Maconnection.Open();
                int resultat = maRequete.ExecuteNonQuery();
                Connection.Maconnection.Close();
                //renvoi si ca bien la modif a ete prise en compte
                if (resultat > 0) { reponse = true; }
                else { throw new Exception("une erreur s'est produite, l'auter n'a pas été supprimé"); }

                return reponse;
            }


            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            
        }
    }
}
