﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ADO_45
{
    public partial class FormAdherent : Form
    {
        List<Adherent> lesAdherents = new List<Adherent>();
        public FormAdherent()
        {
            InitializeComponent();
            RemplirListe();
        }

        private void RemplirListe()
        {
            try
            {
                //dataGridView1.Rows.Clear();
                //appelle Donne auteur et renvoi une liste 
                lesAdherents = ManagerAdherent.DonneAdherents();
                bs.DataSource = lesAdherents;

            }
            catch (Exception ex)
            {
                MessageBox.Show("erreur:" + ex.Message);
            }

            finally
            {

            }

        }

        private void Afficher_Click(object sender, EventArgs e)
        {
            Adherent adhselec = new Adherent();
            DataGridViewRow ligne = dataGridView1.SelectedRows[0];
            adhselec = ligne.DataBoundItem as Adherent;
            if (adhselec != null)
            {
              FicheAdherent   frm = new FicheAdherent(false, adhselec);
                frm.ShowDialog();
            }
        }

        private void Modifier_Click(object sender, EventArgs e)
        {
            Adherent Adhselec = new Adherent();
            DataGridViewRow ligne = dataGridView1.SelectedRows[0];
            Adhselec = ligne.DataBoundItem as Adherent;
            if (Adhselec != null)
            {
                FicheAdherent frm = new FicheAdherent(true, Adhselec);
                frm.ShowDialog();
            }
        }

        private void Supprimer_Click(object sender, EventArgs e)
        {
            Adherent adhselec = new Adherent();
            DataGridViewRow ligne = dataGridView1.SelectedRows[0];
            adhselec = ligne.DataBoundItem as Adherent;

            //boite dialogue qui demande l'accord avant suppression 
            const string message =
                "veux tu vraiment supprimer cette auteur ?";//question 
            const string caption = "Form Closing";
            var result = MessageBox.Show(message, caption,
                                         MessageBoxButtons.YesNo,
                                         MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                // annule l'action
                ManagerAdherent.SupprimerAdherent(adhselec);
                RemplirListe();
            }
        }

        private void Nouveau_Click(object sender, EventArgs e)
        {
            Adherent adhSelec = new Adherent();
            FicheAdherent frm = new FicheAdherent(true, adhSelec);
            frm.ShowDialog();
            RemplirListe();
        }

       
    }
}
