﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_45
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void auteursToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1(); //permet d'afficher la liste des auteurs 
            frm.Show();
        }

        private void genresToolStripMenuItem_Click(object sender, EventArgs e)
        {

            FormGenre frm = new FormGenre(); //permet d'afficher la liste des genre 
            frm.Show();
        }

        private void adherenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAdherent frm = new FormAdherent(); //permet d'afficher la liste des adherent
            frm.Show();
        }
    }
}
